# Ax Runner

App Android que ejecuta módulos tipo AxManager/KernelSU (con `module.prop`, `service.sh`, `webroot/`)
y les da la API de WebUI (`ksu.exec`, iconos de apps…). Pensada para tu módulo **AI-Auto-Mode**.

## Compilar el APK sin Android Studio (≈ 5 min)
1. Crea un repositorio en GitHub y sube **todo el contenido de esta carpeta** (incluida `.github`).
2. Entra en la pestaña **Actions** → **Build APK** → **Run workflow** (se lanza solo al subir).
3. Al terminar (check verde) abre la ejecución y descarga el artefacto **AxRunner-APK** (zip con el `.apk`).
4. Instala el APK en el móvil.

## Compilar con Android Studio
Abre la carpeta, deja que sincronice Gradle y pulsa Build → Build APK(s).

## Usarlo
1. Instala **Shizuku** y arráncalo (Ajustes → Opciones de desarrollador → Depuración inalámbrica, Android 11+).
2. Abre **Ax Runner** → **Permiso Shizuku** → acepta.
3. **Instalar módulo (.zip)** → elige `AI-Auto-Mode-vX.zip`. Se copia a `/data/local/tmp/axr/<id>/` y arranca.
4. **Abrir** muestra la WebUI del módulo.

## Límites conocidos
- Necesita Shizuku (o root). No incluye su propio emparejamiento de depuración inalámbrica.
- Shizuku no arranca solo tras reiniciar el móvil (sin root): hay que volver a iniciarlo y abrir Ax Runner.
- Código escrito sin poder compilarlo ni probarlo en un móvil: puede requerir pequeños ajustes.
