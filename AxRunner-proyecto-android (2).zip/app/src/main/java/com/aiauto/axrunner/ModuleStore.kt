package com.aiauto.axrunner

import android.content.Context
import android.net.Uri
import java.io.File
import java.util.zip.ZipFile

data class Module(
    val id: String, val name: String, val version: String,
    val author: String, val desc: String, val hasWeb: Boolean
)

/**
 * Los módulos se despliegan en /data/local/tmp/axr/<id>/ (lo puede leer el shell de ADB)
 * y su carpeta webroot también se copia a la app para mostrarla en el WebView.
 */
object ModuleStore {
    const val DEPLOY = "/data/local/tmp/axr"
    private val SAFE = Regex("^[A-Za-z0-9._/ -]+\$")
    private val SAFE_ID = Regex("^[A-Za-z0-9_.-]+\$")

    fun modsDir(ctx: Context) = File(ctx.filesDir, "mods")
    fun uiDir(ctx: Context, id: String) = File(ctx.filesDir, "ui/$id")

    fun parseProps(text: String): Map<String, String> =
        text.lines().mapNotNull { l ->
            val i = l.indexOf('=')
            if (i > 0 && !l.trimStart().startsWith("#")) l.substring(0, i).trim() to l.substring(i + 1).trim() else null
        }.toMap()

    fun list(ctx: Context): List<Module> {
        val dirs = modsDir(ctx).listFiles() ?: return emptyList()
        return dirs.filter { File(it, "module.prop").exists() }.sortedBy { it.name }.map { d ->
            val p = parseProps(File(d, "module.prop").readText())
            Module(
                id = d.name,
                name = p["name"] ?: d.name,
                version = p["version"] ?: "?",
                author = p["author"] ?: "",
                desc = p["description"] ?: "",
                hasWeb = File(uiDir(ctx, d.name), "index.html").exists()
            )
        }
    }

    /** Instala un .zip de módulo. Devuelve el id o lanza una excepción con el motivo. */
    fun install(ctx: Context, zipUri: Uri): String {
        val tmp = File(ctx.cacheDir, "incoming.zip")
        val input = ctx.contentResolver.openInputStream(zipUri) ?: throw Exception("No se pudo abrir el archivo")
        input.use { i -> tmp.outputStream().use { o -> i.copyTo(o) } }

        return ZipFile(tmp).use { z ->
            val propEntry = z.getEntry("module.prop") ?: throw Exception("El zip no tiene module.prop")
            val props = parseProps(z.getInputStream(propEntry).bufferedReader().readText())
            val id = props["id"] ?: throw Exception("module.prop no tiene id")
            if (!SAFE_ID.matches(id)) throw Exception("El id del módulo no es válido")

            val dest = "$DEPLOY/$id"
            val r0 = Shell.run("rm -rf '$dest' && mkdir -p '$dest' && chmod 755 '$DEPLOY' '$dest'")
            if (r0.code != 0) throw Exception("No se pudo crear $dest (¿motor sin permisos?): ${r0.err.trim()}")

            val ui = uiDir(ctx, id); ui.deleteRecursively(); ui.mkdirs()
            val mdir = File(modsDir(ctx), id); mdir.deleteRecursively(); mdir.mkdirs()

            for (e in z.entries().toList()) {
                if (e.isDirectory) continue
                val name = e.name
                if (name.contains("..") || !SAFE.matches(name)) continue
                val bytes = z.getInputStream(e).readBytes()
                val path = "$dest/$name"
                val dir = path.substringBeforeLast('/')
                val r = Shell.run("mkdir -p '$dir' && cat > '$path' && chmod 755 '$path'", bytes)
                if (r.code != 0) throw Exception("Falló al copiar $name: ${r.err.trim()}")
                if (name.startsWith("webroot/")) {
                    val f = File(ui, name.removePrefix("webroot/"))
                    f.parentFile?.mkdirs(); f.writeBytes(bytes)
                }
            }
            File(mdir, "module.prop").writeBytes(z.getInputStream(propEntry).readBytes())
            id
        }
    }

    fun start(id: String): ExecResult =
        Shell.run("cd '$DEPLOY/$id' && [ -f service.sh ] && (nohup sh '$DEPLOY/$id/service.sh' >/dev/null 2>&1 &) ; echo started")

    fun stop(id: String): ExecResult =
        Shell.run("for p in \$(pgrep -f '$DEPLOY/$id/service.sh'); do kill \$p; done; echo stopped")

    fun action(id: String): ExecResult =
        Shell.run("cd '$DEPLOY/$id' && [ -f action.sh ] && sh '$DEPLOY/$id/action.sh'")

    fun remove(ctx: Context, id: String) {
        Shell.run("[ -f '$DEPLOY/$id/uninstall.sh' ] && sh '$DEPLOY/$id/uninstall.sh'; rm -rf '$DEPLOY/$id'")
        File(modsDir(ctx), id).deleteRecursively()
        uiDir(ctx, id).deleteRecursively()
    }
}
