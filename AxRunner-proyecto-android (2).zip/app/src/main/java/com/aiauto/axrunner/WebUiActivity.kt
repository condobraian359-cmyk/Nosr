package com.aiauto.axrunner

import android.app.Activity
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.os.Bundle
import android.util.Base64
import android.webkit.JavascriptInterface
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.io.File

/** Muestra la webroot de un módulo y le da la API de KernelSU/AxManager (ksu.exec, iconos de apps...). */
class WebUiActivity : Activity() {
    private lateinit var web: WebView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Shell.init(applicationContext)
        val id = intent.getStringExtra("id")
        if (id == null) { finish(); return }

        web = WebView(this)
        web.setBackgroundColor(Color.parseColor("#0B1020"))
        web.fitsSystemWindows = true
        setContentView(web)

        val s = web.settings
        s.javaScriptEnabled = true
        s.domStorageEnabled = true
        s.allowFileAccess = true
        s.allowContentAccess = false
        s.mediaPlaybackRequiresUserGesture = false

        web.addJavascriptInterface(Bridge(this, web, id), "ksu")
        web.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(view: WebView, req: WebResourceRequest): WebResourceResponse? {
                val u = req.url
                if (u.scheme == "ksu" && u.host == "icon") {
                    val pkg = u.pathSegments.firstOrNull() ?: return null
                    val png = iconPng(pkg, 96) ?: return null
                    return WebResourceResponse("image/png", null, ByteArrayInputStream(png))
                }
                return null
            }
        }
        web.loadUrl("file://" + File(ModuleStore.uiDir(this, id), "index.html").absolutePath)
    }

    fun iconPng(pkg: String, size: Int): ByteArray? = try {
        val d = packageManager.getApplicationIcon(pkg)
        val bmp = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        d.setBounds(0, 0, size, size)
        d.draw(c)
        val bos = ByteArrayOutputStream()
        bmp.compress(Bitmap.CompressFormat.PNG, 100, bos)
        bos.toByteArray()
    } catch (_: Exception) { null }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (::web.isInitialized && web.canGoBack()) web.goBack() else super.onBackPressed()
    }

    override fun onDestroy() {
        if (::web.isInitialized) web.destroy()
        super.onDestroy()
    }
}

/** Puente JavaScript compatible con la API de KernelSU WebUI (la misma que usa AxManager). */
class Bridge(private val act: WebUiActivity, private val web: WebView, private val moduleId: String) {
    private val pm: PackageManager = act.packageManager
    private val cbOk = Regex("^[A-Za-z0-9_\\$.]+\$")

    @JavascriptInterface
    fun exec(cmd: String, opts: String?, cb: String) {
        if (!cbOk.matches(cb)) return
        Thread {
            val r = Shell.run(cmd)
            val js = JSONObject().put("errno", r.code).put("stdout", r.out).put("stderr", r.err)
            act.runOnUiThread {
                web.evaluateJavascript("(function(){var f=window['$cb'];if(f)f($js);})()", null)
            }
        }.start()
    }

    @JavascriptInterface
    fun toast(msg: String) { act.runOnUiThread { Toast.makeText(act, msg, Toast.LENGTH_SHORT).show() } }

    @JavascriptInterface
    fun fullScreen(enable: Boolean) { /* la app ya ocupa la pantalla */ }

    @JavascriptInterface
    fun moduleInfo(): String = JSONObject().put("moduleDir", "${ModuleStore.DEPLOY}/$moduleId").put("id", moduleId).toString()

    @JavascriptInterface
    fun listPackages(type: String): String {
        val arr = JSONArray()
        for (a in pm.getInstalledApplications(0)) {
            val sys = (a.flags and ApplicationInfo.FLAG_SYSTEM) != 0
            if (type == "all" || (type == "system" && sys) || (type == "user" && !sys)) arr.put(a.packageName)
        }
        return arr.toString()
    }

    @JavascriptInterface
    fun getPackagesInfo(json: String): String {
        val out = JSONArray()
        val names = JSONArray(json)
        for (i in 0 until names.length()) {
            val p = names.optString(i)
            try {
                val a = pm.getApplicationInfo(p, 0)
                val sys = (a.flags and ApplicationInfo.FLAG_SYSTEM) != 0
                out.put(
                    JSONObject().put("packageName", p)
                        .put("appLabel", pm.getApplicationLabel(a).toString())
                        .put("isSystem", sys).put("uid", a.uid)
                )
            } catch (_: Exception) { /* paquete no instalado */ }
        }
        return out.toString()
    }

    @JavascriptInterface
    fun getPackagesIcons(json: String, size: Int): String {
        val out = JSONArray()
        val names = JSONArray(json)
        val px = if (size in 16..256) size else 96
        for (i in 0 until names.length()) {
            val p = names.optString(i)
            val png = act.iconPng(p, px) ?: continue
            out.put(
                JSONObject().put("packageName", p)
                    .put("icon", "data:image/png;base64," + Base64.encodeToString(png, Base64.NO_WRAP))
            )
        }
        return out.toString()
    }
}
