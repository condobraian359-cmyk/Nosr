package com.aiauto.axrunner

import android.content.Context
import android.content.SharedPreferences
import android.content.pm.PackageManager
import rikka.shizuku.Shizuku
import java.io.ByteArrayOutputStream

/** Resultado de ejecutar un comando. */
data class ExecResult(val code: Int, val out: String, val err: String)

/** Un "motor" capaz de ejecutar comandos con más permisos que la propia app. */
interface Backend {
    val label: String
    fun available(): Boolean
    fun run(cmd: String, stdin: ByteArray? = null): ExecResult
}

/** Lee salida y error en paralelo, envía stdin y espera al proceso. */
private fun drain(p: Process, stdin: ByteArray?): ExecResult {
    val outB = ByteArrayOutputStream()
    val errB = ByteArrayOutputStream()
    val t1 = Thread { try { p.inputStream.copyTo(outB) } catch (_: Exception) {} }
    val t2 = Thread { try { p.errorStream.copyTo(errB) } catch (_: Exception) {} }
    t1.start(); t2.start()
    try {
        if (stdin != null) p.outputStream.write(stdin)
        p.outputStream.close()
    } catch (_: Exception) {}
    val code = try { p.waitFor() } catch (_: Exception) { -1 }
    t1.join(); t2.join()
    return ExecResult(code, outB.toString("UTF-8"), errB.toString("UTF-8"))
}

/** Shizuku: shell de ADB (uid 2000), igual que usa AxManager. Hay que tener Shizuku instalado y en marcha. */
object ShizukuBackend : Backend {
    override val label = "Shizuku (shell ADB)"

    fun binderReady(): Boolean = try { Shizuku.pingBinder() } catch (_: Throwable) { false }

    fun granted(): Boolean = try {
        binderReady() && !Shizuku.isPreV11() &&
            Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
    } catch (_: Throwable) { false }

    override fun available(): Boolean = granted()

    override fun run(cmd: String, stdin: ByteArray?): ExecResult {
        // newProcess es privado en la API 13 de Shizuku: se llama por reflexión (método habitual).
        val m = Shizuku::class.java.getDeclaredMethod(
            "newProcess",
            Array<String>::class.java, Array<String>::class.java, String::class.java
        )
        m.isAccessible = true
        val p = m.invoke(null, arrayOf("sh", "-c", cmd), null, null) as Process
        return drain(p, stdin)
    }
}

/** Root clásico (su). */
object RootBackend : Backend {
    override val label = "Root (su)"
    @Volatile private var cacheAt = 0L
    @Volatile private var cacheVal = false

    override fun available(): Boolean {
        val now = System.currentTimeMillis()
        if (now - cacheAt < 30_000) return cacheVal
        cacheVal = try { run("id -u").out.trim() == "0" } catch (_: Throwable) { false }
        cacheAt = now
        return cacheVal
    }

    override fun run(cmd: String, stdin: ByteArray?): ExecResult {
        val p = ProcessBuilder("su", "-c", cmd).start()
        return drain(p, stdin)
    }
}

/** Sin privilegios: solo sirve para pruebas (los módulos reales necesitan Shizuku o root). */
object LocalBackend : Backend {
    override val label = "Local (sin privilegios)"
    override fun available(): Boolean = true
    override fun run(cmd: String, stdin: ByteArray?): ExecResult {
        val p = ProcessBuilder("sh", "-c", cmd).start()
        return drain(p, stdin)
    }
}

object Shell {
    private lateinit var prefs: SharedPreferences

    fun init(ctx: Context) {
        if (!::prefs.isInitialized) prefs = ctx.applicationContext.getSharedPreferences("axr", Context.MODE_PRIVATE)
    }

    fun pref(): String = prefs.getString("backend", "auto") ?: "auto"
    fun setPref(v: String) { prefs.edit().putString("backend", v).apply() }

    fun current(): Backend = when (pref()) {
        "shizuku" -> ShizukuBackend
        "root" -> RootBackend
        "local" -> LocalBackend
        else -> when {
            ShizukuBackend.available() -> ShizukuBackend
            RootBackend.available() -> RootBackend
            else -> LocalBackend
        }
    }

    fun run(cmd: String, stdin: ByteArray? = null): ExecResult =
        try { current().run(cmd, stdin) } catch (e: Throwable) { ExecResult(-1, "", e.toString()) }
}
