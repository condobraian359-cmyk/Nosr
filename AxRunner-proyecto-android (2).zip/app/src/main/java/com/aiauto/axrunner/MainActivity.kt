package com.aiauto.axrunner

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import rikka.shizuku.Shizuku

/** Pantalla principal: estado del motor, instalar módulos y abrirlos. Todo se dibuja por código (sin XML). */
class MainActivity : Activity() {
    private lateinit var root: LinearLayout
    private lateinit var status: TextView
    private lateinit var list: LinearLayout
    private var autostarted = false

    private val bg = Color.parseColor("#0B1020")
    private val card = Color.parseColor("#151C33")
    private val accent = Color.parseColor("#8EA2FF")
    private val muted = Color.parseColor("#8A94B8")

    private fun Int.dp(): Int = (this * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Shell.init(applicationContext)
        window.statusBarColor = bg
        window.navigationBarColor = bg

        val scroll = ScrollView(this)
        scroll.setBackgroundColor(bg)
        root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(16.dp(), 20.dp(), 16.dp(), 24.dp())
        scroll.addView(root)
        setContentView(scroll)

        root.addView(text("Ax Runner", 26f, Color.WHITE, true))
        root.addView(text("Ejecuta módulos (service.sh + WebUI) con Shizuku o root", 13f, muted, false))

        val engine = box()
        status = text("Comprobando motor…", 14f, Color.WHITE, false)
        engine.addView(status)
        val row = LinearLayout(this); row.orientation = LinearLayout.HORIZONTAL
        row.addView(button("Permiso Shizuku") { askShizuku() }, weight())
        row.addView(button("Cambiar motor") { pickBackend() }, weight())
        engine.addView(row)
        root.addView(engine)

        val row2 = LinearLayout(this); row2.orientation = LinearLayout.HORIZONTAL
        row2.addView(button("＋ Instalar módulo (.zip)") { pickZip() }, weight())
        row2.addView(button("▶ Iniciar activos") { startAll(true) }, weight())
        root.addView(row2)

        list = LinearLayout(this); list.orientation = LinearLayout.VERTICAL
        root.addView(list)
    }

    override fun onResume() {
        super.onResume()
        refreshStatus()
        refreshList()
    }

    // ---------- utilidades de interfaz ----------
    private fun text(t: String, size: Float, color: Int, bold: Boolean): TextView {
        val v = TextView(this)
        v.text = t; v.textSize = size; v.setTextColor(color)
        if (bold) v.setTypeface(null, Typeface.BOLD)
        v.setPadding(0, 4.dp(), 0, 4.dp())
        return v
    }

    private fun box(): LinearLayout {
        val b = LinearLayout(this)
        b.orientation = LinearLayout.VERTICAL
        val g = GradientDrawable(); g.setColor(card); g.cornerRadius = 18.dp().toFloat()
        b.background = g
        b.setPadding(14.dp(), 12.dp(), 14.dp(), 12.dp())
        val lp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
        lp.topMargin = 12.dp()
        b.layoutParams = lp
        return b
    }

    private fun button(t: String, onClick: () -> Unit): Button {
        val b = Button(this)
        b.text = t; b.isAllCaps = false; b.textSize = 13f
        b.setTextColor(Color.WHITE)
        val g = GradientDrawable(); g.setColor(Color.parseColor("#26305A")); g.cornerRadius = 14.dp().toFloat()
        b.background = g
        b.setOnClickListener { onClick() }
        return b
    }

    private fun weight(): LinearLayout.LayoutParams {
        val lp = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        lp.setMargins(3.dp(), 6.dp(), 3.dp(), 0)
        return lp
    }

    private fun toast(s: String) = runOnUiThread { Toast.makeText(this, s, Toast.LENGTH_LONG).show() }

    // ---------- motor ----------
    private fun refreshStatus() {
        Thread {
            val sh = ShizukuBackend
            val txt = StringBuilder()
            txt.append("Motor elegido: ").append(Shell.pref()).append("\n")
            txt.append("• Shizuku: ").append(
                when {
                    !sh.binderReady() -> "no está en marcha (ábrelo y arráncalo)"
                    sh.granted() -> "listo ✓"
                    else -> "en marcha, falta dar permiso a esta app"
                }
            ).append("\n")
            txt.append("• Root: ").append(if (RootBackend.available()) "disponible ✓" else "no disponible").append("\n")
            txt.append("En uso: ").append(Shell.current().label)
            runOnUiThread { status.text = txt.toString() }
        }.start()
    }

    private fun askShizuku() {
        try {
            if (!ShizukuBackend.binderReady()) { toast("Abre Shizuku y arráncalo primero"); return }
            if (Shizuku.isPreV11()) { toast("Tu Shizuku es muy antiguo: actualízalo"); return }
            if (Shizuku.checkSelfPermission() == android.content.pm.PackageManager.PERMISSION_GRANTED) {
                toast("Ya tiene permiso"); return
            }
            Shizuku.requestPermission(100)
        } catch (e: Throwable) { toast("Shizuku: ${e.message}") }
    }

    private fun pickBackend() {
        val names = arrayOf("Automático", "Shizuku", "Root", "Local (pruebas)")
        val keys = arrayOf("auto", "shizuku", "root", "local")
        AlertDialog.Builder(this).setTitle("Motor de ejecución")
            .setItems(names) { _, i -> Shell.setPref(keys[i]); refreshStatus() }.show()
    }

    // ---------- módulos ----------
    private fun pickZip() {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT)
        i.addCategory(Intent.CATEGORY_OPENABLE)
        i.type = "*/*"
        startActivityForResult(i, 7)
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != 7 || resultCode != RESULT_OK) return
        val uri: Uri = data?.data ?: return
        toast("Instalando módulo…")
        Thread {
            try {
                val id = ModuleStore.install(this, uri)
                toast("Módulo instalado: $id")
                ModuleStore.start(id)
            } catch (e: Throwable) { toast("No se pudo instalar: ${e.message}") }
            runOnUiThread { refreshList() }
        }.start()
    }

    private fun startAll(manual: Boolean) {
        Thread {
            if (Shell.current() === LocalBackend && !manual) return@Thread
            val enabled = ModuleStore.list(this).filter { prefsEnabled(it.id) }
            for (m in enabled) ModuleStore.start(m.id)
            if (manual) toast("Iniciados: ${enabled.size}")
        }.start()
    }

    private fun prefsEnabled(id: String): Boolean =
        getSharedPreferences("axr", MODE_PRIVATE).getBoolean("en_$id", true)

    private fun refreshList() {
        list.removeAllViews()
        val mods = ModuleStore.list(this)
        if (mods.isEmpty()) {
            list.addView(text("Aún no hay módulos. Pulsa «Instalar módulo» y elige el .zip.", 13f, muted, false))
            return
        }
        for (m in mods) list.addView(moduleCard(m))
        if (!autostarted) { autostarted = true; startAll(false) }
    }

    private fun moduleCard(m: Module): View {
        val c = box()
        c.addView(text("${m.name}  v${m.version}", 17f, Color.WHITE, true))
        if (m.desc.isNotEmpty()) c.addView(text(m.desc, 12f, muted, false))

        val sw = Switch(this)
        sw.text = "Iniciar al abrir la app"
        sw.setTextColor(Color.WHITE)
        sw.isChecked = prefsEnabled(m.id)
        sw.setOnCheckedChangeListener { _, on ->
            getSharedPreferences("axr", MODE_PRIVATE).edit().putBoolean("en_${m.id}", on).apply()
        }
        c.addView(sw)

        val r = LinearLayout(this); r.orientation = LinearLayout.HORIZONTAL
        if (m.hasWeb) r.addView(button("Abrir") {
            val i = Intent(this, WebUiActivity::class.java); i.putExtra("id", m.id); startActivity(i)
        }, weight())
        r.addView(button("Iniciar") {
            Thread { val x = ModuleStore.start(m.id); toast(if (x.code == 0) "Iniciado" else "Error: ${x.err.trim()}") }.start()
        }, weight())
        r.addView(button("Detener") {
            Thread { ModuleStore.stop(m.id); toast("Detenido") }.start()
        }, weight())
        r.addView(button("Eliminar") {
            AlertDialog.Builder(this).setTitle("Eliminar ${m.name}")
                .setMessage("Se ejecuta su uninstall.sh (si lo tiene) y se borra.")
                .setPositiveButton("Eliminar") { _, _ ->
                    Thread { ModuleStore.remove(this, m.id); runOnUiThread { refreshList() } }.start()
                }.setNegativeButton("Cancelar", null).show()
        }, weight())
        c.addView(r)
        return c
    }
}
